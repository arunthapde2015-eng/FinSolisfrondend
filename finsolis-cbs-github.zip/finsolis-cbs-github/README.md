# FinSolis — Core Banking System (CBS)

A single-page React application simulating a Core Banking System for **Swarjy Urban Co-op Credit Society**, a Maharashtra-style cooperative credit society. Built as a UI/workflow prototype covering the full breadth of cooperative banking operations.

## ⚠️ Important — what this project actually is

This is a **frontend simulation, not a production banking system**. There is no backend, no database, and no real authentication:

- All data (accounts, loans, ledger, members, etc.) lives in **React state, in memory**. Refreshing the page resets everything to the seeded demo data.
- Login uses hardcoded demo credentials in the source (see `LOGIN_CREDENTIALS` near the top of `src/App.jsx`).
- GL postings, interest calculations, TDS/GST, NPA classification and every other financial computation are implemented in JavaScript and are internally consistent (double-entry balances, etc.), but nothing here has been reviewed for real regulatory or financial-audit compliance.

Treat this as a **UI/UX and workflow reference implementation** — a starting point for understanding what a cooperative-society CBS's screens and flows could look like, not something to connect to real customer money.

## Architecture — a note on file size

Nearly all application logic currently lives in **one file**, `src/App.jsx` (~19,000+ lines). This was built incrementally over many feature requests in a single conversation, and splitting it into smaller modules (separate files per feature area — Loans, Deposits, NPA, TDS/GST, Meetings, Registers, etc.) was intentionally **not** done here, to avoid the risk of introducing cross-file reference bugs while repackaging.

If you plan to develop this further, the natural next step is to split `App.jsx` by feature area (each major module — e.g. NPA classification, TDS & GST, Meetings & Board, Registers, Communication — is written as a fairly self-contained block of state + functions + JSX within the file, searchable by its section comment headers like `// ==================== NPA Classification & Provisioning ====================`).

## Getting started

```bash
npm install
npm run dev
```

Open the URL Vite prints (typically `http://localhost:5173`).

To build a production bundle:

```bash
npm run build
npm run preview   # serve the build locally to check it
```

### Demo login

Check `LOGIN_CREDENTIALS` and the seeded `users` array near the top of `src/App.jsx` for demo usernames/passwords (e.g. a Super Admin, a Branch Manager, and a Teller account are seeded, each with different role permissions).

## What's implemented

This covers a large surface area of cooperative-bank operations, including:

- **Core banking**: customer & member management, account opening (Savings/Current/FD/RD/Pigmy), cash transactions, fund transfers (NEFT/RTGS/IMPS style), cheque/receipt/passbook registers.
- **Lending**: full Loan Origination workflow, EMI collection, restructuring, foreclosure, write-off, loan document generation & printing (English/Marathi/Bilingual), NPA classification & provisioning per RBI/co-op norms with configurable thresholds, Standing Instructions & eNACH mandates.
- **Accounting**: a real double-entry GL engine (Chart of Accounts, Trial Balance, Balance Sheet & P&L, a Transaction Engine viewer with voucher numbering and reversal support), TDS on deposit interest (Section 194A logic with Form 15G/15H), CGST/SGST/IGST on fee-based services.
- **Governance & compliance**: a Meetings & Board Management module (agendas, resolutions with FY-wise numbering, quorum enforcement, minutes with a finalize-then-read-only lock), a Voter List generator for AGM/society elections, a regulatory MIS report matching the Maharashtra Cooperative Commissioner's circular format.
- **Operations**: Payroll, SMS/WhatsApp communication with automated reminder rules, Investment Management (Call/MIS/SLR), Locker Management, SWIP (sweep-in/out), a Centralized Register Management module (Passbook/Cheque Book/Receipt Book with leaf-level cheque tracking).

## Tech stack

- **React 18** (function components, hooks — no external state management library; everything is `useState`/`useMemo` at the top of one component)
- **lucide-react** for icons
- **recharts** for the few chart visualizations
- **xlsx (SheetJS)** for Excel export of reports
- **Vite** for dev server & bundling

No CSS framework — styling is a large inline `<style>` block injected by the component itself.

## License

Not specified — add one appropriate to your use case before distributing.
